
public class Mat5 {
	boolean Exist = false;
	boolean init=true;
	int n=0;
}
