
public class Mat2 {
	boolean Exist = false;
	boolean init=true;
	int n=0;
}
