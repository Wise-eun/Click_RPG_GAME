import java.lang.reflect.Field;
import java.nio.charset.Charset;

public class Main {

	public static final int SCREEN_WIDTH = 626;
	public static final int SCREEN_HEIGHT = 375;

	


	
	public static void main(String[] args) {
		
		new Start();
	}

}