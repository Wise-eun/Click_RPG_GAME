
public class Sword {
	int STR=20;
	boolean init=true;
	boolean Exist=false;
	boolean wear = false;
	int n;
}
