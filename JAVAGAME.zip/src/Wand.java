
public class Wand {
	int INT=20;
	boolean Exist = false;
	boolean wear = false;
	int n;
	public boolean init = true;
}
