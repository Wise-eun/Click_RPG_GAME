
public class Mat4 {
	boolean Exist = false;
	boolean init=true;
	int n=0;
}
