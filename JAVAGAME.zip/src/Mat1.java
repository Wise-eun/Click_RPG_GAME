
public class Mat1 {
	boolean Exist = false;
	boolean init = true;
	int n = 0;
}
