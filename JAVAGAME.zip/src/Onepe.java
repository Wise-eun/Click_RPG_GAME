
public class Onepe {
	boolean Exist=false;
	boolean wear = false;
	boolean init=true;
	int n=0;
}
