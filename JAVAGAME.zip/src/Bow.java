
public class Bow {
	int DEX = 20;
	boolean init=true;
	boolean Exist = false;
	boolean wear = false;
	int n=0;
}
