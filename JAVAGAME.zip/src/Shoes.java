
public class Shoes {
	boolean Exist = false;
	boolean init=true;
	int n=0;
	boolean wear = false;
}
