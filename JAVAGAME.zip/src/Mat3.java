
public class Mat3 {
	boolean Exist = false;
	boolean init=true;
	int n=0;
}
