
public class SharedItem {
	Sword sword=new Sword();
	boolean wearing =false;
	Bow bow = new Bow();
	Wand wand = new Wand();
	Onepe onepe = new Onepe();
	Shoes shoes = new Shoes();
	Mat1 mat1 = new Mat1();
	Mat2 mat2 = new Mat2();
	Mat3 mat3 = new Mat3();
	Mat4 mat4 = new Mat4();
	Mat5 mat5 = new Mat5();
	
}
